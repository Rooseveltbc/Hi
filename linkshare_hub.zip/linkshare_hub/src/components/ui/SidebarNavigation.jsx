import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const SidebarNavigation = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const authStatus = localStorage.getItem('isAuthenticated') === 'true';
    setIsAuthenticated(authStatus);
  }, [location]);

  const navigationItems = [
    {
      label: 'Home',
      path: '/public-news-feed',
      icon: 'Home',
      tooltip: 'View latest posts and updates'
    },
    {
      label: 'Explore',
      path: '/explore',
      icon: 'Compass',
      tooltip: 'Discover trending content and hashtags'
    },
    {
      label: 'Research Papers',
      path: '/research-papers',
      icon: 'FileText',
      tooltip: 'Browse academic and professional content'
    }
  ];

  const adminItems = [
    {
      label: 'Dashboard',
      path: '/admin-dashboard',
      icon: 'LayoutDashboard',
      tooltip: 'Admin control panel and analytics',
      adminOnly: true
    }
  ];

  const allItems = [...navigationItems, ...(isAuthenticated ? adminItems : [])];

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileMenuOpen(false);
  };

  const isActivePath = (path) => {
    return location.pathname === path;
  };

  // Desktop Sidebar
  const DesktopSidebar = () => (
    <aside className="hidden lg:flex lg:fixed lg:left-0 lg:top-16 lg:bottom-0 lg:w-60 lg:bg-background lg:border-r lg:border-border lg:z-999">
      <nav className="flex flex-col w-full p-4 space-y-2">
        {allItems.map((item) => (
          <Button
            key={item.path}
            variant={isActivePath(item.path) ? "default" : "ghost"}
            onClick={() => handleNavigation(item.path)}
            iconName={item.icon}
            iconPosition="left"
            className="justify-start w-full"
            title={item.tooltip}
          >
            {item.label}
          </Button>
        ))}
      </nav>
    </aside>
  );

  // Mobile Bottom Navigation
  const MobileBottomNav = () => (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-background border-t border-border z-998">
      <div className="flex items-center justify-around px-2 py-2">
        {allItems.slice(0, 4).map((item) => (
          <Button
            key={item.path}
            variant="ghost"
            size="sm"
            onClick={() => handleNavigation(item.path)}
            className={`flex flex-col items-center space-y-1 min-h-12 px-2 ${
              isActivePath(item.path) ? 'text-primary' : 'text-muted-foreground'
            }`}
          >
            <Icon 
              name={item.icon} 
              size={20} 
              color={isActivePath(item.path) ? 'var(--color-primary)' : 'currentColor'} 
            />
            <span className="text-xs font-medium">{item.label}</span>
          </Button>
        ))}
        
        {allItems.length > 4 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="flex flex-col items-center space-y-1 min-h-12 px-2 text-muted-foreground"
          >
            <Icon name="MoreHorizontal" size={20} />
            <span className="text-xs font-medium">More</span>
          </Button>
        )}
      </div>

      {/* Mobile Overflow Menu */}
      {isMobileMenuOpen && allItems.length > 4 && (
        <div className="absolute bottom-full left-0 right-0 bg-background border-t border-border shadow-modal">
          <div className="p-4 space-y-2">
            {allItems.slice(4).map((item) => (
              <Button
                key={item.path}
                variant={isActivePath(item.path) ? "default" : "ghost"}
                onClick={() => handleNavigation(item.path)}
                iconName={item.icon}
                iconPosition="left"
                className="justify-start w-full"
              >
                {item.label}
              </Button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );

  return (
    <>
      <DesktopSidebar />
      <MobileBottomNav />
    </>
  );
};

export default SidebarNavigation;