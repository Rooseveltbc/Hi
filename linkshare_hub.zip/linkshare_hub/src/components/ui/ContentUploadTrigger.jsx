import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const ContentUploadTrigger = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const authStatus = localStorage.getItem('isAuthenticated') === 'true';
    setIsAuthenticated(authStatus);
  }, [location]);

  useEffect(() => {
    if (location.pathname === '/content-upload-modal') {
      setIsModalOpen(true);
    } else {
      setIsModalOpen(false);
    }
  }, [location]);

  const handleUploadClick = () => {
    if (!isAuthenticated) {
      navigate('/admin-login');
      return;
    }
    navigate('/content-upload-modal');
  };

  const handleCloseModal = () => {
    navigate(-1);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      {/* Desktop Upload Button - Top Right */}
      <div className="hidden md:block fixed top-20 right-6 z-999">
        <Button
          variant="default"
          onClick={handleUploadClick}
          iconName="Plus"
          iconPosition="left"
          className="shadow-card"
        >
          Upload Content
        </Button>
      </div>

      {/* Mobile Floating Action Button - Bottom Right */}
      <div className="md:hidden fixed bottom-20 right-4 z-999">
        <Button
          variant="default"
          size="icon"
          onClick={handleUploadClick}
          className="w-14 h-14 rounded-full shadow-modal"
        >
          <Icon name="Plus" size={24} color="white" />
        </Button>
      </div>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-1001 flex items-center justify-center p-4">
          <div className="bg-background rounded-lg shadow-modal w-full max-w-2xl max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="text-xl font-heading font-semibold text-foreground">
                Upload New Content
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleCloseModal}
              >
                <Icon name="X" size={20} />
              </Button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto">
              <div className="space-y-6">
                {/* URL Input Section */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Content URL
                    </label>
                    <div className="relative">
                      <Icon 
                        name="Link" 
                        size={20} 
                        className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
                      />
                      <input
                        type="url"
                        placeholder="https://example.com/article"
                        className="w-full pl-10 pr-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-smooth"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Paste a URL to automatically fetch content metadata
                    </p>
                  </div>

                  <Button
                    variant="outline"
                    iconName="Download"
                    iconPosition="left"
                    className="w-full"
                  >
                    Fetch Content Preview
                  </Button>
                </div>

                {/* Content Preview Section */}
                <div className="border border-border rounded-lg p-4 bg-muted">
                  <div className="flex items-center space-x-2 mb-3">
                    <Icon name="Eye" size={16} className="text-muted-foreground" />
                    <span className="text-sm font-medium text-muted-foreground">Content Preview</span>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="w-full h-32 bg-background border border-border rounded-md flex items-center justify-center">
                      <div className="text-center text-muted-foreground">
                        <Icon name="Image" size={32} className="mx-auto mb-2" />
                        <p className="text-sm">Media preview will appear here</p>
                      </div>
                    </div>
                    
                    <div>
                      <input
                        type="text"
                        placeholder="Content title will be fetched automatically"
                        className="w-full px-3 py-2 bg-background border border-border rounded-md text-sm"
                      />
                    </div>
                    
                    <div>
                      <textarea
                        placeholder="Content description will be fetched automatically"
                        rows={3}
                        className="w-full px-3 py-2 bg-background border border-border rounded-md text-sm resize-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Additional Options */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Tags & Categories
                    </label>
                    <input
                      type="text"
                      placeholder="#technology #news @mention"
                      className="w-full px-3 py-2 bg-input border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-smooth"
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Add hashtags and mentions for better discoverability
                    </p>
                  </div>

                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="publishNow"
                      className="w-4 h-4 text-primary border-border rounded focus:ring-primary"
                    />
                    <label htmlFor="publishNow" className="text-sm text-foreground">
                      Publish immediately
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end space-x-3 p-6 border-t border-border bg-muted">
              <Button
                variant="outline"
                onClick={handleCloseModal}
              >
                Cancel
              </Button>
              <Button
                variant="default"
                iconName="Upload"
                iconPosition="left"
              >
                Upload Content
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ContentUploadTrigger;