import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Image from '../AppImage';
import Button from './Button';

const FeedContainer = ({ children }) => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const observerRef = useRef();
  const location = useLocation();
  const navigate = useNavigate();

  // Extract search query from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const search = urlParams.get('search') || '';
    setSearchQuery(search);
    
    // Reset posts when search changes
    setPosts([]);
    setPage(1);
    setHasMore(true);
  }, [location.search]);

  // Mock data generator
  const generateMockPosts = useCallback((pageNum, query = '') => {
    const mockPosts = [];
    const startId = (pageNum - 1) * 10 + 1;
    
    for (let i = 0; i < 10; i++) {
      const id = startId + i;
      const postTypes = ['article', 'video', 'image', 'link'];
      const type = postTypes[Math.floor(Math.random() * postTypes.length)];
      
      const post = {
        id,
        type,
        title: query 
          ? `Search result for "${query}" - Post ${id}` 
          : `Interesting ${type} content - Post ${id}`,
        description: `This is a sample description for post ${id}. It contains relevant information about the shared content and provides context for viewers.`,
        url: `https://example.com/content/${id}`,
        imageUrl: `https://picsum.photos/400/300?random=${id}`,
        author: `User${Math.floor(Math.random() * 100) + 1}`,
        timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
        likes: Math.floor(Math.random() * 500),
        comments: Math.floor(Math.random() * 50),
        shares: Math.floor(Math.random() * 25),
        tags: [`#tag${Math.floor(Math.random() * 10) + 1}`, `#category${Math.floor(Math.random() * 5) + 1}`],
        mentions: Math.random() > 0.7 ? [`@user${Math.floor(Math.random() * 20) + 1}`] : []
      };
      
      mockPosts.push(post);
    }
    
    return mockPosts;
  }, []);

  // Load posts
  const loadPosts = useCallback(async (pageNum, isNewSearch = false) => {
    if (loading) return;
    
    setLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newPosts = generateMockPosts(pageNum, searchQuery);
    
    if (isNewSearch) {
      setPosts(newPosts);
    } else {
      setPosts(prev => [...prev, ...newPosts]);
    }
    
    setHasMore(newPosts.length === 10);
    setLoading(false);
  }, [loading, searchQuery, generateMockPosts]);

  // Initial load and search changes
  useEffect(() => {
    loadPosts(1, true);
  }, [searchQuery]);

  // Infinite scroll observer
  const lastPostElementRef = useCallback(node => {
    if (loading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        setPage(prevPage => {
          const nextPage = prevPage + 1;
          loadPosts(nextPage, false);
          return nextPage;
        });
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [loading, hasMore, loadPosts]);

  const handleLike = (postId) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, likes: post.likes + 1, isLiked: !post.isLiked }
        : post
    ));
  };

  const handleShare = (postId) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      navigator.clipboard.writeText(post.url);
      // Could show toast notification here
    }
  };

  const handleHashtagClick = (hashtag) => {
    navigate(`/public-news-feed?search=${encodeURIComponent(hashtag)}`);
  };

  const handleMentionClick = (mention) => {
    navigate(`/public-news-feed?search=${encodeURIComponent(mention)}`);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  // Loading skeleton component
  const PostSkeleton = () => (
    <div className="bg-card rounded-lg shadow-card p-6 animate-pulse">
      <div className="flex items-center space-x-3 mb-4">
        <div className="w-10 h-10 bg-muted rounded-full"></div>
        <div className="flex-1">
          <div className="h-4 bg-muted rounded w-24 mb-2"></div>
          <div className="h-3 bg-muted rounded w-16"></div>
        </div>
      </div>
      <div className="space-y-3">
        <div className="h-4 bg-muted rounded w-3/4"></div>
        <div className="h-3 bg-muted rounded w-full"></div>
        <div className="h-3 bg-muted rounded w-2/3"></div>
        <div className="h-48 bg-muted rounded-lg"></div>
        <div className="flex space-x-6">
          <div className="h-8 bg-muted rounded w-16"></div>
          <div className="h-8 bg-muted rounded w-16"></div>
          <div className="h-8 bg-muted rounded w-16"></div>
        </div>
      </div>
    </div>
  );

  return (
    <main className="min-h-screen bg-background pt-16 pb-16 lg:pb-4 lg:pl-60">
      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Search Results Header */}
        {searchQuery && (
          <div className="mb-6 p-4 bg-muted rounded-lg">
            <div className="flex items-center space-x-2">
              <Icon name="Search" size={20} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Search results for: <strong className="text-foreground">"{searchQuery}"</strong>
              </span>
            </div>
          </div>
        )}

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.map((post, index) => (
            <article
              key={post.id}
              ref={index === posts.length - 1 ? lastPostElementRef : null}
              className="bg-card rounded-lg shadow-card hover:shadow-modal transition-smooth"
            >
              {/* Post Header */}
              <div className="p-6 pb-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <Icon name="User" size={20} color="white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground">{post.author}</h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      {formatTimestamp(post.timestamp)}
                    </p>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Icon name="MoreHorizontal" size={16} />
                  </Button>
                </div>

                {/* Post Content */}
                <div className="space-y-3">
                  <h2 className="text-lg font-heading font-semibold text-foreground">
                    {post.title}
                  </h2>
                  <p className="text-foreground leading-relaxed">
                    {post.description}
                  </p>

                  {/* Tags and Mentions */}
                  {(post.tags.length > 0 || post.mentions.length > 0) && (
                    <div className="flex flex-wrap gap-2">
                      {post.tags.map((tag, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleHashtagClick(tag)}
                          className="text-sm text-primary hover:text-secondary transition-micro"
                        >
                          {tag}
                        </button>
                      ))}
                      {post.mentions.map((mention, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleMentionClick(mention)}
                          className="text-sm text-accent hover:text-accent/80 transition-micro"
                        >
                          {mention}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Post Media */}
              <div className="px-6 pb-4">
                <div className="relative rounded-lg overflow-hidden bg-muted">
                  <Image
                    src={post.imageUrl}
                    alt={post.title}
                    className="w-full h-64 object-cover hover:scale-105 transition-smooth cursor-pointer"
                    onClick={() => window.open(post.url, '_blank')}
                  />
                  <div className="absolute top-3 right-3">
                    <div className="bg-black bg-opacity-50 rounded-full p-2">
                      <Icon name="ExternalLink" size={16} color="white" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Post Actions */}
              <div className="px-6 pb-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-6">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(post.id)}
                      className={`space-x-2 ${post.isLiked ? 'text-error' : 'text-muted-foreground'}`}
                    >
                      <Icon 
                        name={post.isLiked ? "Heart" : "Heart"} 
                        size={18} 
                        className={post.isLiked ? 'fill-current' : ''} 
                      />
                      <span className="font-mono text-sm">{post.likes}</span>
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="space-x-2 text-muted-foreground"
                    >
                      <Icon name="MessageCircle" size={18} />
                      <span className="font-mono text-sm">{post.comments}</span>
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleShare(post.id)}
                      className="space-x-2 text-muted-foreground"
                    >
                      <Icon name="Share" size={18} />
                      <span className="font-mono text-sm">{post.shares}</span>
                    </Button>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-muted-foreground"
                  >
                    <Icon name="Bookmark" size={18} />
                  </Button>
                </div>
              </div>
            </article>
          ))}

          {/* Loading Skeletons */}
          {loading && (
            <>
              <PostSkeleton />
              <PostSkeleton />
              <PostSkeleton />
            </>
          )}

          {/* End of Feed Message */}
          {!hasMore && posts.length > 0 && (
            <div className="text-center py-8">
              <div className="inline-flex items-center space-x-2 text-muted-foreground">
                <Icon name="CheckCircle" size={20} />
                <span>You've reached the end of the feed</span>
              </div>
            </div>
          )}
        </div>

        {/* Custom children content */}
        {children}
      </div>
    </main>
  );
};

export default FeedContainer;