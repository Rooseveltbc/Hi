import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Input from './Input';
import Button from './Button';

const AuthenticatedHeader = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const authStatus = localStorage.getItem('isAuthenticated') === 'true';
    setIsAuthenticated(authStatus);
  }, [location]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/public-news-feed?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
      setIsSearchExpanded(false);
    }
  };

  const handleLogoClick = () => {
    navigate('/public-news-feed');
  };

  const handleAdminDashboard = () => {
    navigate('/admin-dashboard');
  };

  const handleLogin = () => {
    navigate('/admin-login');
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    setIsAuthenticated(false);
    navigate('/public-news-feed');
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-background border-b border-border z-1000">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Logo */}
        <div className="flex items-center">
          <button
            onClick={handleLogoClick}
            className="flex items-center space-x-2 hover:opacity-80 transition-micro"
          >
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Share2" size={20} color="white" />
            </div>
            <span className="font-heading font-bold text-xl text-foreground hidden sm:block">
              LinkShare Hub
            </span>
          </button>
        </div>

        {/* Desktop Search */}
        <div className="hidden md:flex flex-1 max-w-md mx-8">
          <form onSubmit={handleSearch} className="w-full">
            <div className="relative">
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
              />
              <Input
                type="search"
                placeholder="Search posts, hashtags, mentions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full bg-muted border-0 rounded-lg focus:bg-background focus:ring-2 focus:ring-primary"
              />
            </div>
          </form>
        </div>

        {/* Mobile Search Toggle */}
        <div className="md:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSearchExpanded(!isSearchExpanded)}
          >
            <Icon name="Search" size={20} />
          </Button>
        </div>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center space-x-3">
          {isAuthenticated ? (
            <>
              <Button
                variant="outline"
                onClick={handleAdminDashboard}
                iconName="LayoutDashboard"
                iconPosition="left"
              >
                Dashboard
              </Button>
              <Button
                variant="ghost"
                onClick={handleLogout}
                iconName="LogOut"
                iconPosition="left"
              >
                Logout
              </Button>
            </>
          ) : (
            <Button
              variant="default"
              onClick={handleLogin}
              iconName="LogIn"
              iconPosition="left"
            >
              Admin Login
            </Button>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <div className="md:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleMobileMenu}
          >
            <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
          </Button>
        </div>
      </div>

      {/* Mobile Search Expanded */}
      {isSearchExpanded && (
        <div className="md:hidden px-4 pb-4 bg-background border-b border-border">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
              />
              <Input
                type="search"
                placeholder="Search posts, hashtags, mentions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full bg-muted border-0 rounded-lg focus:bg-background focus:ring-2 focus:ring-primary"
                autoFocus
              />
            </div>
          </form>
        </div>
      )}

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-b border-border">
          <div className="px-4 py-3 space-y-2">
            {isAuthenticated ? (
              <>
                <Button
                  variant="ghost"
                  fullWidth
                  onClick={() => {
                    handleAdminDashboard();
                    setIsMobileMenuOpen(false);
                  }}
                  iconName="LayoutDashboard"
                  iconPosition="left"
                  className="justify-start"
                >
                  Dashboard
                </Button>
                <Button
                  variant="ghost"
                  fullWidth
                  onClick={() => {
                    handleLogout();
                    setIsMobileMenuOpen(false);
                  }}
                  iconName="LogOut"
                  iconPosition="left"
                  className="justify-start"
                >
                  Logout
                </Button>
              </>
            ) : (
              <Button
                variant="default"
                fullWidth
                onClick={() => {
                  handleLogin();
                  setIsMobileMenuOpen(false);
                }}
                iconName="LogIn"
                iconPosition="left"
                className="justify-start"
              >
                Admin Login
              </Button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default AuthenticatedHeader;