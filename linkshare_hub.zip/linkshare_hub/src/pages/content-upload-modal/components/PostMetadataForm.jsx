import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const PostMetadataForm = ({ formData, onFormDataChange }) => {
  const [hashtagSuggestions, setHashtagSuggestions] = useState([]);
  const [mentionSuggestions, setMentionSuggestions] = useState([]);
  const [showHashtagSuggestions, setShowHashtagSuggestions] = useState(false);
  const [showMentionSuggestions, setShowMentionSuggestions] = useState(false);
  const tagsInputRef = useRef(null);

  // Mock hashtag suggestions
  const mockHashtags = [
    '#technology', '#innovation', '#ai', '#machinelearning', '#webdev',
    '#react', '#javascript', '#programming', '#coding', '#software',
    '#design', '#ux', '#ui', '#frontend', '#backend', '#fullstack',
    '#startup', '#business', '#entrepreneur', '#marketing', '#social',
    '#news', '#trending', '#viral', '#content', '#media', '#digital'
  ];

  // Mock user mentions
  const mockUsers = [
    { username: '@techguru', name: 'Tech Guru', avatar: 'https://randomuser.me/api/portraits/men/1.jpg' },
    { username: '@designpro', name: 'Design Pro', avatar: 'https://randomuser.me/api/portraits/women/2.jpg' },
    { username: '@codewizard', name: 'Code Wizard', avatar: 'https://randomuser.me/api/portraits/men/3.jpg' },
    { username: '@innovator', name: 'Innovation Expert', avatar: 'https://randomuser.me/api/portraits/women/4.jpg' },
    { username: '@startupfounder', name: 'Startup Founder', avatar: 'https://randomuser.me/api/portraits/men/5.jpg' }
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (tagsInputRef.current && !tagsInputRef.current.contains(event.target)) {
        setShowHashtagSuggestions(false);
        setShowMentionSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTagsChange = (e) => {
    const value = e.target.value;
    onFormDataChange({
      ...formData,
      tags: value
    });

    // Check for hashtag suggestions
    const words = value.split(' ');
    const lastWord = words[words.length - 1];
    
    if (lastWord.startsWith('#') && lastWord.length > 1) {
      const searchTerm = lastWord.substring(1).toLowerCase();
      const filtered = mockHashtags.filter(tag => 
        tag.substring(1).toLowerCase().includes(searchTerm)
      );
      setHashtagSuggestions(filtered.slice(0, 5));
      setShowHashtagSuggestions(true);
      setShowMentionSuggestions(false);
    } else if (lastWord.startsWith('@') && lastWord.length > 1) {
      const searchTerm = lastWord.substring(1).toLowerCase();
      const filtered = mockUsers.filter(user => 
        user.username.substring(1).toLowerCase().includes(searchTerm) ||
        user.name.toLowerCase().includes(searchTerm)
      );
      setMentionSuggestions(filtered.slice(0, 5));
      setShowMentionSuggestions(true);
      setShowHashtagSuggestions(false);
    } else {
      setShowHashtagSuggestions(false);
      setShowMentionSuggestions(false);
    }
  };

  const handleSuggestionClick = (suggestion, type) => {
    const words = formData.tags.split(' ');
    words[words.length - 1] = type === 'hashtag' ? suggestion : suggestion.username;
    const newValue = words.join(' ') + ' ';
    
    onFormDataChange({
      ...formData,
      tags: newValue
    });
    
    setShowHashtagSuggestions(false);
    setShowMentionSuggestions(false);
    tagsInputRef.current?.focus();
  };

  const handleVisibilityChange = (checked) => {
    onFormDataChange({
      ...formData,
      isPublic: checked
    });
  };

  const handleScheduleChange = (checked) => {
    onFormDataChange({
      ...formData,
      schedulePost: checked
    });
  };

  const handleScheduleDateChange = (e) => {
    onFormDataChange({
      ...formData,
      scheduledDate: e.target.value
    });
  };

  return (
    <div className="space-y-6">
      {/* Tags and Mentions */}
      <div className="relative" ref={tagsInputRef}>
        <label className="block text-sm font-medium text-foreground mb-2">
          Tags & Mentions
        </label>
        <div className="relative">
          <Icon 
            name="Hash" 
            size={20} 
            className="absolute left-3 top-3 text-muted-foreground" 
          />
          <textarea
            value={formData.tags || ''}
            onChange={handleTagsChange}
            placeholder="#technology #innovation @username - Add hashtags and mentions"
            rows={3}
            className="w-full pl-10 pr-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition-smooth resize-none"
          />
        </div>
        
        {/* Hashtag Suggestions */}
        {showHashtagSuggestions && hashtagSuggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-background border border-border rounded-lg shadow-modal z-50 max-h-48 overflow-y-auto">
            {hashtagSuggestions.map((hashtag, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(hashtag, 'hashtag')}
                className="w-full px-4 py-2 text-left hover:bg-muted transition-micro flex items-center space-x-2"
              >
                <Icon name="Hash" size={16} className="text-primary" />
                <span className="text-sm text-foreground">{hashtag}</span>
              </button>
            ))}
          </div>
        )}

        {/* Mention Suggestions */}
        {showMentionSuggestions && mentionSuggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-background border border-border rounded-lg shadow-modal z-50 max-h-48 overflow-y-auto">
            {mentionSuggestions.map((user, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(user, 'mention')}
                className="w-full px-4 py-2 text-left hover:bg-muted transition-micro flex items-center space-x-3"
              >
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{user.username}</p>
                  <p className="text-xs text-muted-foreground">{user.name}</p>
                </div>
              </button>
            ))}
          </div>
        )}

        <p className="text-sm text-muted-foreground mt-2">
          Type # for hashtags or @ for mentions to see suggestions
        </p>
      </div>

      {/* Post Settings */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-foreground">Post Settings</h3>
        
        {/* Visibility Toggle */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <Icon 
                name={formData.isPublic ? "Globe" : "Lock"} 
                size={20} 
                className="text-primary" 
              />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                {formData.isPublic ? 'Public Post' : 'Private Post'}
              </p>
              <p className="text-xs text-muted-foreground">
                {formData.isPublic 
                  ? 'Visible to all users in the feed' :'Only visible to administrators'
                }
              </p>
            </div>
          </div>
          <Checkbox
            checked={formData.isPublic || false}
            onChange={(e) => handleVisibilityChange(e.target.checked)}
            className="ml-4"
          />
        </div>

        {/* Schedule Post */}
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <Checkbox
              checked={formData.schedulePost || false}
              onChange={(e) => handleScheduleChange(e.target.checked)}
            />
            <div>
              <p className="text-sm font-medium text-foreground">Schedule for later</p>
              <p className="text-xs text-muted-foreground">
                Choose a specific date and time to publish
              </p>
            </div>
          </div>

          {formData.schedulePost && (
            <div className="ml-6">
              <Input
                type="datetime-local"
                label="Publish Date & Time"
                value={formData.scheduledDate || ''}
                onChange={handleScheduleDateChange}
                min={new Date().toISOString().slice(0, 16)}
                className="w-full"
              />
            </div>
          )}
        </div>
      </div>

      {/* Content Guidelines */}
      <div className="bg-warning/5 border border-warning/20 rounded-lg p-4">
        <div className="flex items-start space-x-2">
          <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground mb-1">Content Guidelines</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Ensure all shared content complies with platform policies</li>
              <li>• Verify that external links are safe and appropriate</li>
              <li>• Add relevant hashtags to improve content discoverability</li>
              <li>• Use mentions to credit original creators when applicable</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostMetadataForm;