import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ModalHeader = ({ onClose, isMobile }) => {
  return (
    <div className={`flex items-center justify-between p-6 border-b border-border bg-background ${isMobile ? 'sticky top-0 z-10' : ''}`}>
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
          <Icon name="Plus" size={20} color="white" />
        </div>
        <div>
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Upload New Content
          </h2>
          <p className="text-sm text-muted-foreground">
            Share external media content with your audience
          </p>
        </div>
      </div>
      
      <Button
        variant="ghost"
        size="icon"
        onClick={onClose}
        className="shrink-0"
      >
        <Icon name="X" size={20} />
      </Button>
    </div>
  );
};

export default ModalHeader;