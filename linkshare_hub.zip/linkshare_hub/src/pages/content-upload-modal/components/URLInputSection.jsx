import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const URLInputSection = ({ url, setUrl, onFetchMetadata, isLoading, validationError }) => {
  const [inputFocused, setInputFocused] = useState(false);

  const supportedPlatforms = [
    { name: 'YouTube', icon: 'Play', example: 'https://youtube.com/watch?v=...' },
    { name: 'Vimeo', icon: 'Video', example: 'https://vimeo.com/...' },
    { name: 'Dailymotion', icon: 'Film', example: 'https://dailymotion.com/video/...' },
    { name: 'Direct Media', icon: 'FileVideo', example: 'https://example.com/video.mp4' }
  ];

  const validateURL = (inputUrl) => {
    if (!inputUrl) return null;
    
    const urlPattern = /^https?:\/\/.+/;
    if (!urlPattern.test(inputUrl)) {
      return 'Please enter a valid URL starting with http:// or https://';
    }

    const supportedPatterns = [
      /youtube\.com\/watch\?v=/,
      /youtu\.be\//,
      /vimeo\.com\/\d+/,
      /dailymotion\.com\/video\//,
      /\.(mp4|webm|ogg|mov|avi)$/i,
      /\.(jpg|jpeg|png|gif|webp)$/i,
      /\.(pdf|doc|docx|ppt|pptx)$/i
    ];

    const isSupported = supportedPatterns.some(pattern => pattern.test(inputUrl));
    if (!isSupported) {
      return 'URL format not supported. Please use YouTube, Vimeo, Dailymotion, or direct media links.';
    }

    return null;
  };

  const handleURLChange = (e) => {
    const newUrl = e.target.value;
    setUrl(newUrl);
  };

  const handleFetchClick = () => {
    const error = validateURL(url);
    if (!error && url.trim()) {
      onFetchMetadata(url.trim());
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleFetchClick();
    }
  };

  return (
    <div className="space-y-6">
      {/* URL Input */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Content URL *
          </label>
          <div className="relative">
            <Icon 
              name="Link" 
              size={20} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
            />
            <Input
              type="url"
              placeholder="https://youtube.com/watch?v=example or https://example.com/video.mp4"
              value={url}
              onChange={handleURLChange}
              onKeyPress={handleKeyPress}
              onFocus={() => setInputFocused(true)}
              onBlur={() => setInputFocused(false)}
              error={validationError}
              className="pl-10 pr-4 py-3"
              required
            />
          </div>
          {validationError && (
            <p className="text-sm text-error mt-1 flex items-center space-x-1">
              <Icon name="AlertCircle" size={16} />
              <span>{validationError}</span>
            </p>
          )}
        </div>

        <Button
          variant="outline"
          onClick={handleFetchClick}
          disabled={!url.trim() || isLoading || !!validateURL(url)}
          loading={isLoading}
          iconName="Download"
          iconPosition="left"
          className="w-full"
        >
          {isLoading ? 'Fetching Content...' : 'Fetch Content Preview'}
        </Button>
      </div>

      {/* Supported Platforms Info */}
      {(inputFocused || !url) && (
        <div className="bg-muted rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-3">
            <Icon name="Info" size={16} className="text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">Supported Platforms</span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {supportedPlatforms.map((platform, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 bg-background rounded-md">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Icon name={platform.icon} size={16} className="text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{platform.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{platform.example}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Tips */}
      <div className="bg-accent/5 border border-accent/20 rounded-lg p-4">
        <div className="flex items-start space-x-2">
          <Icon name="Lightbulb" size={16} className="text-accent mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground mb-1">Quick Tips</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Paste any supported URL and we'll automatically fetch the title, description, and thumbnail</li>
              <li>• You can edit all fetched content before publishing</li>
              <li>• Videos will be embedded with custom player controls</li>
              <li>• Images and documents will show appropriate previews</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default URLInputSection;