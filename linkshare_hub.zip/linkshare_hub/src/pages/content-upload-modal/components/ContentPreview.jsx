import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const ContentPreview = ({ metadata, onMetadataChange }) => {
  if (!metadata) {
    return (
      <div className="border border-border rounded-lg p-6 bg-muted">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Eye" size={16} className="text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Content Preview</span>
        </div>
        
        <div className="space-y-4">
          <div className="w-full h-48 bg-background border border-border rounded-md flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <Icon name="Image" size={48} className="mx-auto mb-3 opacity-50" />
              <p className="text-sm">Enter a URL above to see content preview</p>
              <p className="text-xs mt-1">Thumbnail, title, and description will appear here</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const handleTitleChange = (e) => {
    onMetadataChange({
      ...metadata,
      title: e.target.value
    });
  };

  const handleDescriptionChange = (e) => {
    onMetadataChange({
      ...metadata,
      description: e.target.value
    });
  };

  const getContentTypeIcon = () => {
    switch (metadata.type) {
      case 'video':
        return 'Play';
      case 'image':
        return 'Image';
      case 'document':
        return 'FileText';
      default:
        return 'Link';
    }
  };

  const getContentTypeLabel = () => {
    switch (metadata.type) {
      case 'video':
        return 'Video Content';
      case 'image':
        return 'Image Content';
      case 'document':
        return 'Document Content';
      default:
        return 'Web Content';
    }
  };

  return (
    <div className="border border-border rounded-lg p-6 bg-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Eye" size={16} className="text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Content Preview</span>
        </div>
        <div className="flex items-center space-x-2 px-2 py-1 bg-primary/10 rounded-full">
          <Icon name={getContentTypeIcon()} size={14} className="text-primary" />
          <span className="text-xs font-medium text-primary">{getContentTypeLabel()}</span>
        </div>
      </div>
      
      <div className="space-y-4">
        {/* Media Preview */}
        <div className="relative w-full h-48 bg-background border border-border rounded-md overflow-hidden">
          {metadata.thumbnail ? (
            <div className="relative w-full h-full">
              <Image
                src={metadata.thumbnail}
                alt={metadata.title || 'Content preview'}
                className="w-full h-full object-cover"
              />
              {metadata.type === 'video' && (
                <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center">
                    <Icon name="Play" size={24} className="text-foreground ml-1" />
                  </div>
                </div>
              )}
              {metadata.type === 'document' && (
                <div className="absolute top-2 right-2">
                  <div className="bg-black bg-opacity-70 rounded-full p-2">
                    <Icon name="Download" size={16} color="white" />
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Icon name={getContentTypeIcon()} size={32} className="mx-auto mb-2" />
                <p className="text-sm">No preview available</p>
              </div>
            </div>
          )}
        </div>
        
        {/* Editable Title */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Title *
          </label>
          <input
            type="text"
            value={metadata.title || ''}
            onChange={handleTitleChange}
            placeholder="Enter content title"
            className="w-full px-3 py-2 bg-background border border-border rounded-md text-sm focus:ring-2 focus:ring-primary focus:border-transparent transition-smooth"
            required
          />
        </div>
        
        {/* Editable Description */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Description
          </label>
          <textarea
            value={metadata.description || ''}
            onChange={handleDescriptionChange}
            placeholder="Enter content description"
            rows={4}
            className="w-full px-3 py-2 bg-background border border-border rounded-md text-sm resize-none focus:ring-2 focus:ring-primary focus:border-transparent transition-smooth"
          />
          <p className="text-xs text-muted-foreground mt-1">
            {metadata.description?.length || 0}/500 characters
          </p>
        </div>

        {/* Source URL Display */}
        <div className="flex items-center space-x-2 p-3 bg-muted rounded-md">
          <Icon name="ExternalLink" size={16} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground font-mono truncate">
            {metadata.url}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ContentPreview;