import React from 'react';
import Button from '../../../components/ui/Button';

const ModalFooter = ({ 
  onClose, 
  onPublish, 
  isPublishing, 
  canPublish, 
  formData,
  isMobile 
}) => {
  const getPublishButtonText = () => {
    if (isPublishing) return 'Publishing...';
    if (formData?.schedulePost) return 'Schedule Post';
    return 'Publish Post';
  };

  const getPublishButtonIcon = () => {
    if (formData?.schedulePost) return 'Clock';
    return 'Upload';
  };

  return (
    <div className={`flex items-center justify-between p-6 border-t border-border bg-muted ${isMobile ? 'sticky bottom-0' : ''}`}>
      <div className="flex items-center space-x-4">
        {/* Post Status Indicator */}
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${formData?.isPublic ? 'bg-success' : 'bg-warning'}`}></div>
          <span className="text-xs text-muted-foreground">
            {formData?.isPublic ? 'Public' : 'Private'}
          </span>
        </div>
        
        {formData?.schedulePost && (
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 rounded-full bg-primary"></div>
            <span className="text-xs text-muted-foreground">Scheduled</span>
          </div>
        )}
      </div>

      <div className="flex items-center space-x-3">
        <Button
          variant="outline"
          onClick={onClose}
          disabled={isPublishing}
          className={isMobile ? 'px-6' : ''}
        >
          Cancel
        </Button>
        
        <Button
          variant="default"
          onClick={onPublish}
          disabled={!canPublish || isPublishing}
          loading={isPublishing}
          iconName={getPublishButtonIcon()}
          iconPosition="left"
          className={isMobile ? 'px-6' : ''}
        >
          {getPublishButtonText()}
        </Button>
      </div>
    </div>
  );
};

export default ModalFooter;