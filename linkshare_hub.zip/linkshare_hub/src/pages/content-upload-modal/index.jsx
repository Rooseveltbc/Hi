import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import URLInputSection from './components/URLInputSection';
import ContentPreview from './components/ContentPreview';
import PostMetadataForm from './components/PostMetadataForm';
import ModalHeader from './components/ModalHeader';
import ModalFooter from './components/ModalFooter';

const ContentUploadModal = () => {
  const [url, setUrl] = useState('');
  const [metadata, setMetadata] = useState(null);
  const [formData, setFormData] = useState({
    tags: '',
    isPublic: true,
    schedulePost: false,
    scheduledDate: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [isMobile, setIsMobile] = useState(false);
  
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    if (!isAuthenticated) {
      navigate('/admin-login');
      return;
    }

    // Check mobile viewport
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Prevent body scroll when modal is open
    document.body.style.overflow = 'hidden';
    
    return () => {
      window.removeEventListener('resize', checkMobile);
      document.body.style.overflow = 'unset';
    };
  }, [navigate]);

  const handleClose = () => {
    navigate(-1);
  };

  const validateURL = (inputUrl) => {
    if (!inputUrl) return 'URL is required';
    
    const urlPattern = /^https?:\/\/.+/;
    if (!urlPattern.test(inputUrl)) {
      return 'Please enter a valid URL starting with http:// or https://';
    }

    const supportedPatterns = [
      /youtube\.com\/watch\?v=/,
      /youtu\.be\//,
      /vimeo\.com\/\d+/,
      /dailymotion\.com\/video\//,
      /\.(mp4|webm|ogg|mov|avi)$/i,
      /\.(jpg|jpeg|png|gif|webp)$/i,
      /\.(pdf|doc|docx|ppt|pptx)$/i
    ];

    const isSupported = supportedPatterns.some(pattern => pattern.test(inputUrl));
    if (!isSupported) {
      return 'URL format not supported. Please use YouTube, Vimeo, Dailymotion, or direct media links.';
    }

    return null;
  };

  const detectContentType = (url) => {
    if (/youtube\.com|youtu\.be|vimeo\.com|dailymotion\.com/i.test(url)) {
      return 'video';
    }
    if (/\.(mp4|webm|ogg|mov|avi)$/i.test(url)) {
      return 'video';
    }
    if (/\.(jpg|jpeg|png|gif|webp)$/i.test(url)) {
      return 'image';
    }
    if (/\.(pdf|doc|docx|ppt|pptx)$/i.test(url)) {
      return 'document';
    }
    return 'link';
  };

  const generateMockMetadata = (url) => {
    const contentType = detectContentType(url);
    const domain = new URL(url).hostname;
    
    const mockTitles = {
      video: [
        "Amazing Technology Breakthrough in 2025",
        "How AI is Transforming Modern Workflows",
        "The Future of Web Development",
        "Revolutionary Design Patterns Explained",
        "Building Scalable React Applications"
      ],
      image: [
        "Stunning Visual Design Showcase",
        "Creative Photography Collection",
        "Modern UI Design Inspiration",
        "Beautiful Landscape Photography",
        "Innovative Graphic Design Concepts"
      ],
      document: [
        "Comprehensive Research Report 2025",
        "Technical Documentation Guide",
        "Industry Analysis and Insights",
        "Best Practices Whitepaper",
        "Strategic Planning Framework"
      ],
      link: [
        "Interesting Article About Technology",
        "Latest Industry News and Updates",
        "Comprehensive Guide to Modern Tools",
        "Expert Insights and Analysis",
        "Trending Topics in Tech"
      ]
    };

    const mockDescriptions = {
      video: `This engaging video content explores cutting-edge concepts and provides valuable insights for viewers. Perfect for sharing with your audience to spark meaningful discussions and engagement.`,
      image: `A visually stunning piece that captures attention and conveys powerful messages through imagery. Ideal for inspiring your community and generating visual interest in your feed.`,
      document: `Comprehensive documentation that provides in-depth analysis and valuable information. Essential reading for professionals looking to stay informed about industry developments.`,
      link: `Informative content that offers valuable perspectives and insights on current topics. Great for sharing knowledge and fostering community engagement around important subjects.`
    };

    const randomTitle = mockTitles[contentType][Math.floor(Math.random() * mockTitles[contentType].length)];
    
    return {
      url,
      type: contentType,
      title: randomTitle,
      description: mockDescriptions[contentType],
      thumbnail: contentType === 'image' ? url : `https://picsum.photos/400/300?random=${Date.now()}`,
      domain,
      author: 'Content Creator',
      publishedTime: new Date().toISOString()
    };
  };

  const handleFetchMetadata = async (inputUrl) => {
    const error = validateURL(inputUrl);
    if (error) {
      setValidationError(error);
      return;
    }

    setValidationError('');
    setIsLoading(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockMetadata = generateMockMetadata(inputUrl);
      setMetadata(mockMetadata);
    } catch (error) {
      setValidationError('Failed to fetch content metadata. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePublish = async () => {
    if (!metadata || !metadata.title.trim()) {
      setValidationError('Please provide a title for your post');
      return;
    }

    setIsPublishing(true);

    try {
      // Simulate publishing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock successful publish
      const postData = {
        id: Date.now(),
        ...metadata,
        ...formData,
        publishedAt: formData.schedulePost ? formData.scheduledDate : new Date().toISOString(),
        status: formData.schedulePost ? 'scheduled' : 'published'
      };

      console.log('Published post:', postData);
      
      // Navigate back to dashboard or feed
      navigate('/admin-dashboard');
    } catch (error) {
      setValidationError('Failed to publish post. Please try again.');
    } finally {
      setIsPublishing(false);
    }
  };

  const canPublish = metadata && metadata.title && metadata.title.trim().length > 0;

  // Mobile full-screen modal
  if (isMobile) {
    return (
      <div className="fixed inset-0 bg-background z-1001 flex flex-col">
        <ModalHeader onClose={handleClose} isMobile={true} />
        
        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-8">
            <URLInputSection
              url={url}
              setUrl={setUrl}
              onFetchMetadata={handleFetchMetadata}
              isLoading={isLoading}
              validationError={validationError}
            />

            <ContentPreview
              metadata={metadata}
              onMetadataChange={setMetadata}
            />

            {metadata && (
              <PostMetadataForm
                formData={formData}
                onFormDataChange={setFormData}
              />
            )}
          </div>
        </div>

        <ModalFooter
          onClose={handleClose}
          onPublish={handlePublish}
          isPublishing={isPublishing}
          canPublish={canPublish}
          formData={formData}
          isMobile={true}
        />
      </div>
    );
  }

  // Desktop centered modal
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-1001 flex items-center justify-center p-4">
      <div className="bg-background rounded-lg shadow-modal w-full max-w-4xl max-h-[90vh] flex flex-col">
        <ModalHeader onClose={handleClose} isMobile={false} />
        
        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Column - URL Input and Form */}
              <div className="space-y-8">
                <URLInputSection
                  url={url}
                  setUrl={setUrl}
                  onFetchMetadata={handleFetchMetadata}
                  isLoading={isLoading}
                  validationError={validationError}
                />

                {metadata && (
                  <PostMetadataForm
                    formData={formData}
                    onFormDataChange={setFormData}
                  />
                )}
              </div>

              {/* Right Column - Content Preview */}
              <div className="lg:sticky lg:top-0">
                <ContentPreview
                  metadata={metadata}
                  onMetadataChange={setMetadata}
                />
              </div>
            </div>
          </div>
        </div>

        <ModalFooter
          onClose={handleClose}
          onPublish={handlePublish}
          isPublishing={isPublishing}
          canPublish={canPublish}
          formData={formData}
          isMobile={false}
        />
      </div>
    </div>
  );
};

export default ContentUploadModal;