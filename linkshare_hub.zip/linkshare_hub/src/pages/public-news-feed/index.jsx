import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import AuthenticatedHeader from '../../components/ui/AuthenticatedHeader';
import SidebarNavigation from '../../components/ui/SidebarNavigation';
import ContentUploadTrigger from '../../components/ui/ContentUploadTrigger';
import PostCard from './components/PostCard';
import PostSkeleton from './components/PostSkeleton';
import SearchResultsHeader from './components/SearchResultsHeader';
import EndOfFeedMessage from './components/EndOfFeedMessage';
import EmptyFeedMessage from './components/EmptyFeedMessage';

const PublicNewsFeed = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [initialLoad, setInitialLoad] = useState(true);
  const observerRef = useRef();
  const location = useLocation();
  const navigate = useNavigate();

  // Extract search query from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const search = urlParams.get('search') || '';
    setSearchQuery(search);
    
    // Reset posts when search changes
    setPosts([]);
    setPage(1);
    setHasMore(true);
    setInitialLoad(true);
  }, [location.search]);

  // Mock data generator with rich media content
  const generateMockPosts = useCallback((pageNum, query = '') => {
    const mockPosts = [];
    const startId = (pageNum - 1) * 10 + 1;
    
    const contentTypes = [
      {
        type: 'youtube',
        videoId: 'dQw4w9WgXcQ',
        title: 'Amazing Technology Demo - Revolutionary AI Breakthrough',
        description: `Check out this incredible demonstration of cutting-edge AI technology! This video showcases the latest developments in machine learning and artificial intelligence. #AI #Technology #Innovation @TechExpert @AIResearcher\n\nThe future is here and it's more exciting than ever. What do you think about these advancements?`
      },
      {
        type: 'vimeo',videoId: '148751763',title: 'Creative Design Process - Behind the Scenes',
        description: `Take a look behind the scenes of our creative design process. This video shows how we approach complex design challenges and create stunning visual experiences. #Design #Creative #Process @DesignStudio\n\nCreativity meets technology in this fascinating journey.`
      },
      {
        type: 'video',videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',thumbnail: 'https://picsum.photos/400/300?random=video',title: 'Product Launch Event Highlights',
        description: `Highlights from our recent product launch event. See the excitement, innovation, and community that makes our products special. #ProductLaunch #Innovation #Community @ProductTeam\n\nThank you to everyone who joined us for this amazing event!`
      },
      {
        type: 'image',imageUrl: 'https://picsum.photos/800/600?random=image',title: 'Stunning Photography Collection',
        description: `A beautiful collection of landscape photography from around the world. Nature's beauty captured in these breathtaking moments. #Photography #Nature #Landscape @Photographer\n\nWhich location would you love to visit?`
      },
      {
        type: 'document',
        documentTitle: 'Research Paper: Future of Web Development',
        documentType: 'PDF',
        documentSize: '2.4 MB',
        title: 'Latest Research on Web Development Trends',
        description: `Our comprehensive research paper on the future of web development is now available. Discover emerging trends, technologies, and best practices. #WebDev #Research #Technology @ResearchTeam\n\nDownload and share your thoughts on these findings.`
      },
      {
        type: 'link',
        thumbnail: 'https://picsum.photos/400/300?random=link',
        title: 'Industry News: Major Tech Announcement',
        description: `Breaking news in the tech industry! Major companies are announcing significant changes that will impact the entire sector. #TechNews #Industry #Breaking @NewsTeam @TechAnalyst\n\nWhat are your thoughts on these developments?`
      }
    ];

    for (let i = 0; i < 10; i++) {
      const id = startId + i;
      const contentTemplate = contentTypes[i % contentTypes.length];
      
      const post = {
        id,
        ...contentTemplate,
        title: query 
          ? `${contentTemplate.title} - Search: "${query}"` 
          : contentTemplate.title,
        url: `https://example.com/content/${id}`,
        author: `ContentCurator${Math.floor(Math.random() * 5) + 1}`,
        timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
        likes: Math.floor(Math.random() * 500) + 50,
        comments: Math.floor(Math.random() * 100) + 10,
        shares: Math.floor(Math.random() * 50) + 5,
        tags: [`#tag${Math.floor(Math.random() * 10) + 1}`, `#category${Math.floor(Math.random() * 5) + 1}`],
        mentions: Math.random() > 0.6 ? [`@user${Math.floor(Math.random() * 20) + 1}`, `@expert${Math.floor(Math.random() * 10) + 1}`] : [],
        isLiked: Math.random() > 0.8
      };
      
      mockPosts.push(post);
    }
    
    return mockPosts;
  }, []);

  // Load posts with realistic loading simulation
  const loadPosts = useCallback(async (pageNum, isNewSearch = false) => {
    if (loading) return;
    
    setLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, isNewSearch ? 500 : 800));
    
    const newPosts = generateMockPosts(pageNum, searchQuery);
    
    if (isNewSearch) {
      setPosts(newPosts);
    } else {
      setPosts(prev => [...prev, ...newPosts]);
    }
    
    setHasMore(newPosts.length === 10 && pageNum < 5); // Limit to 5 pages for demo
    setLoading(false);
    setInitialLoad(false);
  }, [loading, searchQuery, generateMockPosts]);

  // Initial load and search changes
  useEffect(() => {
    loadPosts(1, true);
  }, [searchQuery]);

  // Infinite scroll observer
  const lastPostElementRef = useCallback(node => {
    if (loading) return;
    if (observerRef.current) observerRef.current.disconnect();
    
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        setPage(prevPage => {
          const nextPage = prevPage + 1;
          loadPosts(nextPage, false);
          return nextPage;
        });
      }
    });
    
    if (node) observerRef.current.observe(node);
  }, [loading, hasMore, loadPosts]);

  // Post interaction handlers
  const handleLike = (postId) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            likes: post.isLiked ? post.likes - 1 : post.likes + 1,
            isLiked: !post.isLiked 
          }
        : post
    ));
  };

  const handleShare = (postId) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      if (navigator.share) {
        navigator.share({
          title: post.title,
          text: post.description,
          url: post.url
        });
      } else {
        navigator.clipboard.writeText(post.url);
      }
      
      // Update share count
      setPosts(prev => prev.map(p => 
        p.id === postId 
          ? { ...p, shares: p.shares + 1 }
          : p
      ));
    }
  };

  const handleHashtagClick = (hashtag) => {
    navigate(`/public-news-feed?search=${encodeURIComponent(hashtag)}`);
  };

  const handleMentionClick = (mention) => {
    navigate(`/public-news-feed?search=${encodeURIComponent(mention)}`);
  };

  const handleClearSearch = () => {
    navigate('/public-news-feed');
  };

  return (
    <>
      <Helmet>
        <title>Public News Feed - LinkShare Hub</title>
        <meta name="description" content="Discover curated content from around the web. Videos, articles, images, and documents shared by our community." />
        <meta name="keywords" content="social media, content sharing, videos, articles, news feed" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <AuthenticatedHeader />
        <SidebarNavigation />
        <ContentUploadTrigger />

        <main className="pt-16 pb-16 lg:pb-4 lg:pl-60">
          <div className="max-w-2xl mx-auto px-4 py-6">
            <SearchResultsHeader 
              searchQuery={searchQuery} 
              onClearSearch={handleClearSearch}
            />

            {/* Posts Feed */}
            <div className="space-y-6">
              {initialLoad && loading ? (
                // Initial loading skeletons
                <>
                  <PostSkeleton />
                  <PostSkeleton />
                  <PostSkeleton />
                </>
              ) : posts.length === 0 && !loading ? (
                // Empty state
                <EmptyFeedMessage 
                  searchQuery={searchQuery}
                  onClearSearch={handleClearSearch}
                />
              ) : (
                // Posts list
                <>
                  {posts.map((post, index) => (
                    <div
                      key={post.id}
                      ref={index === posts.length - 1 ? lastPostElementRef : null}
                    >
                      <PostCard
                        post={post}
                        onLike={handleLike}
                        onShare={handleShare}
                        onHashtagClick={handleHashtagClick}
                        onMentionClick={handleMentionClick}
                      />
                    </div>
                  ))}

                  {/* Loading more skeletons */}
                  {loading && !initialLoad && (
                    <>
                      <PostSkeleton />
                      <PostSkeleton />
                    </>
                  )}

                  {/* End of feed message */}
                  <EndOfFeedMessage hasAnyPosts={posts.length > 0 && !hasMore} />
                </>
              )}
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default PublicNewsFeed;