import React from 'react';
import Icon from '../../../components/AppIcon';

const EndOfFeedMessage = ({ hasAnyPosts }) => {
  if (!hasAnyPosts) return null;

  return (
    <div className="text-center py-8">
      <div className="inline-flex items-center space-x-2 text-muted-foreground">
        <Icon name="CheckCircle" size={20} />
        <span className="text-sm">You've reached the end of the feed</span>
      </div>
      <p className="text-xs text-muted-foreground mt-2">
        Check back later for more content
      </p>
    </div>
  );
};

export default EndOfFeedMessage;