import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const EmptyFeedMessage = ({ searchQuery, onClearSearch }) => {
  if (searchQuery) {
    return (
      <div className="text-center py-16">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Search" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
          No results found
        </h3>
        <p className="text-muted-foreground mb-4 max-w-md mx-auto">
          We couldn't find any posts matching "{searchQuery}". Try searching with different keywords or hashtags.
        </p>
        <Button
          variant="outline"
          onClick={onClearSearch}
          iconName="ArrowLeft"
          iconPosition="left"
        >
          Back to Feed
        </Button>
      </div>
    );
  }

  return (
    <div className="text-center py-16">
      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
        <Icon name="Rss" size={24} className="text-muted-foreground" />
      </div>
      <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
        Welcome to LinkShare Hub
      </h3>
      <p className="text-muted-foreground max-w-md mx-auto">
        Your curated content feed is loading. Discover amazing videos, articles, and media shared by our community.
      </p>
    </div>
  );
};

export default EmptyFeedMessage;