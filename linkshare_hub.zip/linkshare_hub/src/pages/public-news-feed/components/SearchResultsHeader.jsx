import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SearchResultsHeader = ({ searchQuery, onClearSearch }) => {
  if (!searchQuery) return null;

  return (
    <div className="mb-6 p-4 bg-muted rounded-lg border border-border">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Icon name="Search" size={20} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            Search results for: <strong className="text-foreground">"{searchQuery}"</strong>
          </span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearSearch}
          iconName="X"
          iconPosition="left"
          className="text-muted-foreground hover:text-foreground"
        >
          Clear
        </Button>
      </div>
    </div>
  );
};

export default SearchResultsHeader;