import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PostCard = ({ post, onLike, onShare, onHashtagClick, onMentionClick }) => {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [videoCurrentTime, setVideoCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [videoVolume, setVideoVolume] = useState(1);
  const [isVideoMuted, setIsVideoMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showControls, setShowControls] = useState(false);
  const videoRef = useRef(null);

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVideoPlay = () => {
    if (videoRef.current) {
      videoRef.current.play();
      setIsVideoPlaying(true);
    }
  };

  const handleVideoPause = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      setIsVideoPlaying(false);
    }
  };

  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      setVideoCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleVideoLoadedMetadata = () => {
    if (videoRef.current) {
      setVideoDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const newTime = (clickX / rect.width) * videoDuration;
    if (videoRef.current) {
      videoRef.current.currentTime = newTime;
      setVideoCurrentTime(newTime);
    }
  };

  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    setVideoVolume(newVolume);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
    }
    setIsVideoMuted(newVolume === 0);
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const newMuted = !isVideoMuted;
      videoRef.current.muted = newMuted;
      setIsVideoMuted(newMuted);
      if (newMuted) {
        setVideoVolume(0);
      } else {
        setVideoVolume(0.5);
        videoRef.current.volume = 0.5;
      }
    }
  };

  const handleSpeedChange = (speed) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  const toggleFullscreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      }
    }
  };

  const renderHashtagsAndMentions = (text) => {
    const parts = text.split(/(\#\w+|\@\w+)/g);
    return parts.map((part, index) => {
      if (part.startsWith('#')) {
        return (
          <button
            key={index}
            onClick={() => onHashtagClick(part)}
            className="text-primary hover:text-secondary transition-micro font-medium"
          >
            {part}
          </button>
        );
      } else if (part.startsWith('@')) {
        return (
          <button
            key={index}
            onClick={() => onMentionClick(part)}
            className="text-accent hover:text-accent/80 transition-micro font-medium"
          >
            {part}
          </button>
        );
      }
      return part;
    });
  };

  const renderMediaContent = () => {
    switch (post.type) {
      case 'youtube':
        return (
          <div className="relative rounded-lg overflow-hidden bg-black">
            <iframe
              width="100%"
              height="300"
              src={`https://www.youtube.com/embed/${post.videoId}?enablejsapi=1&modestbranding=1&rel=0`}
              title={post.title}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full"
            />
          </div>
        );

      case 'vimeo':
        return (
          <div className="relative rounded-lg overflow-hidden bg-black">
            <iframe
              width="100%"
              height="300"
              src={`https://player.vimeo.com/video/${post.videoId}?title=0&byline=0&portrait=0`}
              title={post.title}
              frameBorder="0"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              className="w-full"
            />
          </div>
        );

      case 'video':
        return (
          <div 
            className="relative rounded-lg overflow-hidden bg-black group"
            onMouseEnter={() => setShowControls(true)}
            onMouseLeave={() => setShowControls(false)}
          >
            <video
              ref={videoRef}
              className="w-full h-64 object-cover"
              onTimeUpdate={handleVideoTimeUpdate}
              onLoadedMetadata={handleVideoLoadedMetadata}
              poster={post.thumbnail}
            >
              <source src={post.videoUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>

            {/* Custom Video Controls */}
            <div className={`absolute inset-0 bg-black bg-opacity-30 transition-opacity ${showControls ? 'opacity-100' : 'opacity-0'}`}>
              {/* Play/Pause Button */}
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={isVideoPlaying ? handleVideoPause : handleVideoPlay}
                  className="w-16 h-16 bg-black bg-opacity-50 hover:bg-opacity-70 text-white rounded-full"
                >
                  <Icon name={isVideoPlaying ? "Pause" : "Play"} size={24} color="white" />
                </Button>
              </div>

              {/* Bottom Controls */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                {/* Progress Bar */}
                <div 
                  className="w-full h-2 bg-white bg-opacity-30 rounded-full mb-3 cursor-pointer"
                  onClick={handleSeek}
                >
                  <div 
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${(videoCurrentTime / videoDuration) * 100}%` }}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {/* Time Display */}
                    <span className="text-white text-sm font-mono">
                      {formatTime(videoCurrentTime)} / {formatTime(videoDuration)}
                    </span>

                    {/* Volume Control */}
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={toggleMute}
                        className="text-white hover:bg-white hover:bg-opacity-20"
                      >
                        <Icon name={isVideoMuted ? "VolumeX" : "Volume2"} size={16} color="white" />
                      </Button>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.1"
                        value={videoVolume}
                        onChange={handleVolumeChange}
                        className="w-16 h-1 bg-white bg-opacity-30 rounded-full"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {/* Speed Control */}
                    <select
                      value={playbackSpeed}
                      onChange={(e) => handleSpeedChange(parseFloat(e.target.value))}
                      className="bg-black bg-opacity-50 text-white text-sm rounded px-2 py-1 border-0"
                    >
                      <option value={0.5}>0.5x</option>
                      <option value={1}>1x</option>
                      <option value={1.25}>1.25x</option>
                      <option value={1.5}>1.5x</option>
                      <option value={2}>2x</option>
                    </select>

                    {/* Fullscreen Button */}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={toggleFullscreen}
                      className="text-white hover:bg-white hover:bg-opacity-20"
                    >
                      <Icon name="Maximize" size={16} color="white" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'image':
        return (
          <div className="relative rounded-lg overflow-hidden bg-muted group cursor-pointer">
            <Image
              src={post.imageUrl}
              alt={post.title}
              className="w-full h-64 object-cover group-hover:scale-105 transition-smooth"
              onClick={() => window.open(post.url, '_blank')}
            />
            <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="bg-black bg-opacity-50 rounded-full p-2">
                <Icon name="ZoomIn" size={16} color="white" />
              </div>
            </div>
          </div>
        );

      case 'document':
        return (
          <div className="border border-border rounded-lg p-4 bg-muted hover:bg-card transition-smooth">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="FileText" size={24} color="white" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-foreground mb-1">{post.documentTitle}</h4>
                <p className="text-sm text-muted-foreground mb-2">{post.documentType} • {post.documentSize}</p>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Download"
                  iconPosition="left"
                  onClick={() => window.open(post.url, '_blank')}
                >
                  Download
                </Button>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="relative rounded-lg overflow-hidden bg-muted">
            <Image
              src={post.thumbnail || post.imageUrl}
              alt={post.title}
              className="w-full h-64 object-cover hover:scale-105 transition-smooth cursor-pointer"
              onClick={() => window.open(post.url, '_blank')}
            />
            <div className="absolute top-3 right-3">
              <div className="bg-black bg-opacity-50 rounded-full p-2">
                <Icon name="ExternalLink" size={16} color="white" />
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <article className="bg-card rounded-lg shadow-card hover:shadow-modal transition-smooth">
      {/* Post Header */}
      <div className="p-6 pb-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <Icon name="User" size={20} color="white" />
          </div>
          <div className="flex-1">
            <h3 className="font-medium text-foreground">{post.author}</h3>
            <p className="text-sm text-muted-foreground font-mono">
              {formatTimestamp(post.timestamp)}
            </p>
          </div>
          <Button variant="ghost" size="icon">
            <Icon name="MoreHorizontal" size={16} />
          </Button>
        </div>

        {/* Post Content */}
        <div className="space-y-3">
          <h2 className="text-lg font-heading font-semibold text-foreground">
            {post.title}
          </h2>
          <div className="text-foreground leading-relaxed">
            {renderHashtagsAndMentions(post.description)}
          </div>

          {/* Tags and Mentions */}
          {(post.tags?.length > 0 || post.mentions?.length > 0) && (
            <div className="flex flex-wrap gap-2">
              {post.tags?.map((tag, idx) => (
                <button
                  key={idx}
                  onClick={() => onHashtagClick(tag)}
                  className="text-sm text-primary hover:text-secondary transition-micro px-2 py-1 bg-primary/10 rounded-full"
                >
                  {tag}
                </button>
              ))}
              {post.mentions?.map((mention, idx) => (
                <button
                  key={idx}
                  onClick={() => onMentionClick(mention)}
                  className="text-sm text-accent hover:text-accent/80 transition-micro px-2 py-1 bg-accent/10 rounded-full"
                >
                  {mention}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Post Media */}
      <div className="px-6 pb-4">
        {renderMediaContent()}
      </div>

      {/* Post Actions */}
      <div className="px-6 pb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onLike(post.id)}
              className={`space-x-2 ${post.isLiked ? 'text-error' : 'text-muted-foreground'}`}
            >
              <Icon 
                name="Heart" 
                size={18} 
                className={post.isLiked ? 'fill-current' : ''} 
              />
              <span className="font-mono text-sm">{post.likes}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="space-x-2 text-muted-foreground"
            >
              <Icon name="MessageCircle" size={18} />
              <span className="font-mono text-sm">{post.comments}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => onShare(post.id)}
              className="space-x-2 text-muted-foreground"
            >
              <Icon name="Share" size={18} />
              <span className="font-mono text-sm">{post.shares}</span>
            </Button>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground"
          >
            <Icon name="Bookmark" size={18} />
          </Button>
        </div>
      </div>
    </article>
  );
};

export default PostCard;