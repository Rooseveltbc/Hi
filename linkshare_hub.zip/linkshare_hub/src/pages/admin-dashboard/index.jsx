import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthenticatedHeader from '../../components/ui/AuthenticatedHeader';
import SidebarNavigation from '../../components/ui/SidebarNavigation';
import ContentUploadTrigger from '../../components/ui/ContentUploadTrigger';
import MetricsCard from './components/MetricsCard';
import ActivityChart from './components/ActivityChart';
import RecentPostsTable from './components/RecentPostsTable';
import QuickActions from './components/QuickActions';
import NotificationPanel from './components/NotificationPanel';

const AdminDashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    if (!isAuthenticated) {
      navigate('/admin-login');
      return;
    }
  }, [navigate]);

  const metricsData = [
    {
      title: "Total Posts",
      value: "127",
      change: "+12%",
      changeType: "positive",
      icon: "FileText",
      color: "primary"
    },
    {
      title: "Total Engagement",
      value: "8.2K",
      change: "+18%",
      changeType: "positive",
      icon: "Heart",
      color: "success"
    },
    {
      title: "Active Users",
      value: "1.4K",
      change: "+5%",
      changeType: "positive",
      icon: "Users",
      color: "warning"
    },
    {
      title: "Pending Reviews",
      value: "3",
      change: "-2",
      changeType: "negative",
      icon: "Clock",
      color: "error"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <AuthenticatedHeader />
      <SidebarNavigation />
      <ContentUploadTrigger />
      
      <main className="pt-16 pb-16 lg:pb-4 lg:pl-60">
        <div className="max-w-7xl mx-auto px-4 py-6">
          {/* Breadcrumb */}
          <div className="mb-6">
            <nav className="flex items-center space-x-2 text-sm text-muted-foreground">
              <span>Admin</span>
              <span>/</span>
              <span className="text-foreground font-medium">Dashboard</span>
            </nav>
          </div>

          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-heading font-bold text-foreground mb-2">
              Dashboard Overview
            </h1>
            <p className="text-muted-foreground">
              Monitor your content performance and manage platform activity
            </p>
          </div>

          {/* Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {metricsData.map((metric, index) => (
              <MetricsCard
                key={index}
                title={metric.title}
                value={metric.value}
                change={metric.change}
                changeType={metric.changeType}
                icon={metric.icon}
                color={metric.color}
              />
            ))}
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Activity Chart - Takes 2 columns on large screens */}
            <div className="lg:col-span-2">
              <ActivityChart />
            </div>
            
            {/* Quick Actions */}
            <div className="lg:col-span-1">
              <QuickActions />
            </div>
          </div>

          {/* Bottom Section */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            {/* Recent Posts Table - Takes 2 columns on extra large screens */}
            <div className="xl:col-span-2">
              <RecentPostsTable />
            </div>
            
            {/* Notifications Panel */}
            <div className="xl:col-span-1">
              <NotificationPanel />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;