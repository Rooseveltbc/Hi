import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const RecentPostsTable = () => {
  const [sortBy, setSortBy] = useState('date');
  const [filterType, setFilterType] = useState('all');

  const sortOptions = [
    { value: 'date', label: 'Latest First' },
    { value: 'engagement', label: 'Most Engaged' },
    { value: 'title', label: 'Alphabetical' }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Content' },
    { value: 'video', label: 'Videos' },
    { value: 'image', label: 'Images' },
    { value: 'article', label: 'Articles' },
    { value: 'link', label: 'Links' }
  ];

  const recentPosts = [
    {
      id: 1,
      title: "Advanced React Patterns for 2025",
      type: "article",
      thumbnail: "https://picsum.photos/80/60?random=1",
      publishedAt: "2025-01-24T14:30:00Z",
      likes: 156,
      comments: 23,
      shares: 12,
      status: "published"
    },
    {
      id: 2,
      title: "Building Scalable Web Applications",
      type: "video",
      thumbnail: "https://picsum.photos/80/60?random=2",
      publishedAt: "2025-01-24T10:15:00Z",
      likes: 289,
      comments: 45,
      shares: 28,
      status: "published"
    },
    {
      id: 3,
      title: "UI/UX Design Trends 2025",
      type: "image",
      thumbnail: "https://picsum.photos/80/60?random=3",
      publishedAt: "2025-01-23T16:45:00Z",
      likes: 234,
      comments: 18,
      shares: 15,
      status: "published"
    },
    {
      id: 4,
      title: "JavaScript Performance Optimization",
      type: "article",
      thumbnail: "https://picsum.photos/80/60?random=4",
      publishedAt: "2025-01-23T09:20:00Z",
      likes: 178,
      comments: 31,
      shares: 22,
      status: "draft"
    },
    {
      id: 5,
      title: "Modern CSS Grid Techniques",
      type: "link",
      thumbnail: "https://picsum.photos/80/60?random=5",
      publishedAt: "2025-01-22T13:10:00Z",
      likes: 145,
      comments: 19,
      shares: 8,
      status: "published"
    }
  ];

  const getTypeIcon = (type) => {
    const icons = {
      video: 'Play',
      image: 'Image',
      article: 'FileText',
      link: 'Link'
    };
    return icons[type] || 'File';
  };

  const getStatusColor = (status) => {
    return status === 'published' ? 'text-success' : 'text-warning';
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  const handleEdit = (postId) => {
    console.log('Edit post:', postId);
  };

  const handleDelete = (postId) => {
    console.log('Delete post:', postId);
  };

  return (
    <div className="bg-card rounded-lg shadow-card">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground mb-1">
              Recent Posts
            </h3>
            <p className="text-sm text-muted-foreground">
              Manage your latest content uploads and engagement
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <Select
              options={filterOptions}
              value={filterType}
              onChange={setFilterType}
              placeholder="Filter by type"
              className="w-full sm:w-40"
            />
            <Select
              options={sortOptions}
              value={sortBy}
              onChange={setSortBy}
              placeholder="Sort by"
              className="w-full sm:w-40"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted">
            <tr>
              <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                Content
              </th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground hidden md:table-cell">
                Type
              </th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground hidden lg:table-cell">
                Published
              </th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                Engagement
              </th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground hidden sm:table-cell">
                Status
              </th>
              <th className="text-right py-3 px-6 text-sm font-medium text-muted-foreground">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {recentPosts.map((post) => (
              <tr key={post.id} className="hover:bg-muted/50 transition-micro">
                <td className="py-4 px-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-9 rounded-md overflow-hidden bg-muted flex-shrink-0">
                      <Image
                        src={post.thumbnail}
                        alt={post.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className="text-sm font-medium text-foreground truncate">
                        {post.title}
                      </h4>
                      <p className="text-xs text-muted-foreground md:hidden">
                        {formatDate(post.publishedAt)}
                      </p>
                    </div>
                  </div>
                </td>
                
                <td className="py-4 px-4 hidden md:table-cell">
                  <div className="flex items-center space-x-2">
                    <Icon name={getTypeIcon(post.type)} size={16} className="text-muted-foreground" />
                    <span className="text-sm text-foreground capitalize">{post.type}</span>
                  </div>
                </td>
                
                <td className="py-4 px-4 hidden lg:table-cell">
                  <span className="text-sm text-muted-foreground font-mono">
                    {formatDate(post.publishedAt)}
                  </span>
                </td>
                
                <td className="py-4 px-4">
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Icon name="Heart" size={14} />
                      <span className="font-mono">{post.likes}</span>
                    </div>
                    <div className="flex items-center space-x-1 hidden sm:flex">
                      <Icon name="MessageCircle" size={14} />
                      <span className="font-mono">{post.comments}</span>
                    </div>
                    <div className="flex items-center space-x-1 hidden sm:flex">
                      <Icon name="Share" size={14} />
                      <span className="font-mono">{post.shares}</span>
                    </div>
                  </div>
                </td>
                
                <td className="py-4 px-4 hidden sm:table-cell">
                  <span className={`text-xs font-medium capitalize ${getStatusColor(post.status)}`}>
                    {post.status}
                  </span>
                </td>
                
                <td className="py-4 px-6">
                  <div className="flex items-center justify-end space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(post.id)}
                      className="w-8 h-8"
                    >
                      <Icon name="Edit2" size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(post.id)}
                      className="w-8 h-8 text-error hover:text-error"
                    >
                      <Icon name="Trash2" size={14} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Showing 5 of 127 posts</span>
          <Button variant="ghost" size="sm">
            View All Posts
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RecentPostsTable;