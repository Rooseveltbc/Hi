import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const ActivityChart = () => {
  const chartData = [
    { name: 'Mon', posts: 12, engagement: 245 },
    { name: 'Tue', posts: 19, engagement: 389 },
    { name: 'Wed', posts: 8, engagement: 156 },
    { name: 'Thu', posts: 15, engagement: 298 },
    { name: 'Fri', posts: 22, engagement: 445 },
    { name: 'Sat', posts: 18, engagement: 367 },
    { name: 'Sun', posts: 14, engagement: 278 }
  ];

  return (
    <div className="bg-card rounded-lg shadow-card p-6">
      <div className="mb-6">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
          Weekly Activity Overview
        </h3>
        <p className="text-sm text-muted-foreground">
          Posts published and engagement metrics for the past 7 days
        </p>
      </div>
      
      <div className="w-full h-64" aria-label="Weekly Activity Bar Chart">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              dataKey="name" 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
            />
            <YAxis 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'var(--color-card)',
                border: '1px solid var(--color-border)',
                borderRadius: '8px',
                color: 'var(--color-foreground)'
              }}
            />
            <Bar 
              dataKey="posts" 
              fill="var(--color-primary)" 
              radius={[4, 4, 0, 0]}
              name="Posts"
            />
            <Bar 
              dataKey="engagement" 
              fill="var(--color-secondary)" 
              radius={[4, 4, 0, 0]}
              name="Engagement"
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ActivityChart;