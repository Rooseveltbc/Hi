import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const NotificationPanel = () => {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'comment',
      message: 'New comment on "Advanced React Patterns for 2025"',
      user: 'Sarah Johnson',
      timestamp: '2 minutes ago',
      read: false
    },
    {
      id: 2,
      type: 'like',
      message: 'Your post received 50+ likes',
      user: 'System',
      timestamp: '15 minutes ago',
      read: false
    },
    {
      id: 3,
      type: 'share',
      message: 'Content shared 10 times today',
      user: 'Analytics',
      timestamp: '1 hour ago',
      read: true
    },
    {
      id: 4,
      type: 'mention',
      message: 'You were mentioned in a comment',
      user: 'Mike Chen',
      timestamp: '3 hours ago',
      read: true
    }
  ]);

  const getNotificationIcon = (type) => {
    const icons = {
      comment: 'MessageCircle',
      like: 'Heart',
      share: 'Share',
      mention: 'AtSign'
    };
    return icons[type] || 'Bell';
  };

  const getNotificationColor = (type) => {
    const colors = {
      comment: 'text-primary',
      like: 'text-error',
      share: 'text-success',
      mention: 'text-warning'
    };
    return colors[type] || 'text-muted-foreground';
  };

  const markAsRead = (id) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, read: true }))
    );
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="bg-card rounded-lg shadow-card">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Notifications
            </h3>
            {unreadCount > 0 && (
              <span className="bg-error text-white text-xs font-medium px-2 py-1 rounded-full">
                {unreadCount}
              </span>
            )}
          </div>
          
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={markAllAsRead}
              className="text-xs"
            >
              Mark all read
            </Button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="max-h-80 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="p-8 text-center">
            <Icon name="Bell" size={32} className="mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">No notifications yet</p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-4 hover:bg-muted/50 transition-micro cursor-pointer ${
                  !notification.read ? 'bg-primary/5 border-l-4 border-l-primary' : ''
                }`}
                onClick={() => markAsRead(notification.id)}
              >
                <div className="flex items-start space-x-3">
                  <div className={`flex-shrink-0 ${getNotificationColor(notification.type)}`}>
                    <Icon name={getNotificationIcon(notification.type)} size={18} />
                  </div>
                  
                  <div className="min-w-0 flex-1">
                    <p className={`text-sm ${!notification.read ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>
                      {notification.message}
                    </p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-xs text-muted-foreground">
                        {notification.user}
                      </span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground font-mono">
                        {notification.timestamp}
                      </span>
                    </div>
                  </div>
                  
                  {!notification.read && (
                    <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-2"></div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border bg-muted/30">
        <Button variant="ghost" size="sm" fullWidth>
          View All Notifications
          <Icon name="ArrowRight" size={16} className="ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default NotificationPanel;