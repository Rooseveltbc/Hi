import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';


const QuickActions = () => {
  const navigate = useNavigate();

  const quickActions = [
    {
      title: "Create New Post",
      description: "Upload and share new content",
      icon: "Plus",
      color: "primary",
      action: () => navigate('/content-upload-modal')
    },
    {
      title: "View Public Feed",
      description: "See how content appears to users",
      icon: "Eye",
      color: "secondary",
      action: () => navigate('/public-news-feed')
    },
    {
      title: "Analytics Report",
      description: "Download engagement metrics",
      icon: "BarChart3",
      color: "success",
      action: () => console.log('Generate analytics report')
    },
    {
      title: "Content Settings",
      description: "Manage posting preferences",
      icon: "Settings",
      color: "warning",
      action: () => console.log('Open content settings')
    }
  ];

  const getColorClasses = (color) => {
    const colors = {
      primary: "bg-primary/10 text-primary border-primary/20",
      secondary: "bg-secondary/10 text-secondary border-secondary/20",
      success: "bg-success/10 text-success border-success/20",
      warning: "bg-warning/10 text-warning border-warning/20"
    };
    return colors[color] || colors.primary;
  };

  return (
    <div className="bg-card rounded-lg shadow-card p-6">
      <div className="mb-6">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
          Quick Actions
        </h3>
        <p className="text-sm text-muted-foreground">
          Common tasks and shortcuts for content management
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {quickActions.map((action, index) => (
          <button
            key={index}
            onClick={action.action}
            className={`p-4 rounded-lg border-2 transition-smooth hover:shadow-card text-left ${getColorClasses(action.color)}`}
          >
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0">
                <Icon name={action.icon} size={20} color="currentColor" />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="font-medium text-sm mb-1">{action.title}</h4>
                <p className="text-xs opacity-80 leading-relaxed">{action.description}</p>
              </div>
              <Icon name="ArrowRight" size={16} className="opacity-60" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;