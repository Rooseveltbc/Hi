import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const LoginHeader = () => {
  const navigate = useNavigate();

  const handleLogoClick = () => {
    navigate('/public-news-feed');
  };

  return (
    <div className="text-center mb-8">
      {/* Logo */}
      <button
        onClick={handleLogoClick}
        className="inline-flex items-center space-x-3 hover:opacity-80 transition-micro mb-6"
      >
        <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-card">
          <Icon name="Share2" size={28} color="white" />
        </div>
        <span className="font-heading font-bold text-2xl text-foreground">
          LinkShare Hub
        </span>
      </button>

      {/* Welcome Text */}
      <div className="space-y-2">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Welcome Back
        </h1>
        <p className="text-muted-foreground">
          Sign in to your admin account to manage content
        </p>
      </div>
    </div>
  );
};

export default LoginHeader;