import React from 'react';
import LoginForm from './LoginForm';
import SecurityBadges from './SecurityBadges';

const LoginCard = () => {
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-card rounded-2xl shadow-modal p-8 border border-border">
        {/* Login Form */}
        <LoginForm />
        
        {/* Security Badges */}
        <SecurityBadges />
      </div>
    </div>
  );
};

export default LoginCard;