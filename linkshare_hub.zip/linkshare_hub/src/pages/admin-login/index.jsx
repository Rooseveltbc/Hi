import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginHeader from './components/LoginHeader';
import LoginCard from './components/LoginCard';

const AdminLogin = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    if (isAuthenticated) {
      navigate('/admin-dashboard');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">
          {/* Login Header */}
          <LoginHeader />
          
          {/* Login Card */}
          <LoginCard />
          
          {/* Footer Note */}
          <div className="text-center mt-8">
            <p className="text-sm text-muted-foreground">
              Need help? Contact support at{' '}
              <a 
                href="mailto:support@linksharehub.com" 
                className="text-primary hover:text-secondary transition-micro font-medium"
              >
                support@linksharehub.com
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* Copyright Footer */}
      <footer className="py-6 px-4 border-t border-border bg-muted">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} LinkShare Hub. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default AdminLogin;